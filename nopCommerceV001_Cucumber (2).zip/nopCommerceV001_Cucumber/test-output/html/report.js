$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:Features/Globe.feature");
formatter.feature({
  "name": "Globe",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Successful CheckOut the Wifi",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@sanity"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User can be able to Launch Chrome browser",
  "keyword": "Given "
});
formatter.match({
  "location": "GlobalPOC.user_Launch_Chrome_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded0.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User open URL \"https://onlinepreprod.globe.com.ph/port-number\"",
  "keyword": "When "
});
formatter.match({
  "location": "GlobalPOC.user_opens_URL(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded1.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Page title should be \"Globe Online\"",
  "keyword": "And "
});
formatter.match({
  "location": "GlobalPOC.page_Title_should_be(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded2.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Click on BuyButton",
  "keyword": "Then "
});
formatter.match({
  "location": "GlobalPOC.click_on_Login()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded3.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User should be able to check the buy now button",
  "keyword": "When "
});
formatter.match({
  "location": "GlobalPOC.user_click_on_Log_out_link()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded4.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User can view CheckOut Page",
  "keyword": "Then "
});
formatter.match({
  "location": "GlobalPOC.user_can_clickon_BuynowButton()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded5.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User can view CheckoutDetails \"09270004201\"",
  "keyword": "And "
});
formatter.match({
  "location": "GlobalPOC.user_can_view_Dashboad(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded6.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User view the transaction timed out pop up",
  "keyword": "When "
});
formatter.match({
  "location": "GlobalPOC.user_should_be_able_to_view_reviewbag()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded7.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Application is timed out",
  "keyword": "Then "
});
formatter.match({
  "location": "GlobalPOC.user_should_be_not_able_to_view_transaction_timedout()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded8.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User should not be able to view Review My bag Page",
  "keyword": "And "
});
formatter.match({
  "location": "GlobalPOC.user_should_be_not_able_to_view_ReviewMybagPage()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded9.png");
formatter.afterstep({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "User Should be able to Login to globe and Buy Wifi and navigate to checkout page",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@regression"
    }
  ]
});
formatter.step({
  "name": "User can be able to Launch Chrome browser",
  "keyword": "Given "
});
formatter.step({
  "name": "User open URL \"https://onlinepreprod.globe.com.ph/port-number\"",
  "keyword": "When "
});
formatter.step({
  "name": "Page title should be \"\u003ctitle\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "Click on BuyButton",
  "keyword": "Then "
});
formatter.step({
  "name": "User should be able to check the buy now button",
  "keyword": "When "
});
formatter.step({
  "name": "User can view CheckOut Page",
  "keyword": "Then "
});
formatter.step({
  "name": "User can view CheckoutDetails \"09270004201\"",
  "keyword": "And "
});
formatter.step({
  "name": "User view the transaction timed out pop up",
  "keyword": "When "
});
formatter.step({
  "name": "Application is timed out",
  "keyword": "Then "
});
formatter.step({
  "name": "User should not be able to view Review My bag Page",
  "keyword": "And "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "title"
      ]
    },
    {
      "cells": [
        "Globe Online"
      ]
    }
  ]
});
formatter.scenario({
  "name": "User Should be able to Login to globe and Buy Wifi and navigate to checkout page",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@regression"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User can be able to Launch Chrome browser",
  "keyword": "Given "
});
formatter.match({
  "location": "GlobalPOC.user_Launch_Chrome_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded10.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User open URL \"https://onlinepreprod.globe.com.ph/port-number\"",
  "keyword": "When "
});
formatter.match({
  "location": "GlobalPOC.user_opens_URL(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded11.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Page title should be \"Globe Online\"",
  "keyword": "And "
});
formatter.match({
  "location": "GlobalPOC.page_Title_should_be(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded12.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Click on BuyButton",
  "keyword": "Then "
});
formatter.match({
  "location": "GlobalPOC.click_on_Login()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded13.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User should be able to check the buy now button",
  "keyword": "When "
});
formatter.match({
  "location": "GlobalPOC.user_click_on_Log_out_link()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded14.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User can view CheckOut Page",
  "keyword": "Then "
});
formatter.match({
  "location": "GlobalPOC.user_can_clickon_BuynowButton()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded15.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User can view CheckoutDetails \"09270004201\"",
  "keyword": "And "
});
formatter.match({
  "location": "GlobalPOC.user_can_view_Dashboad(String)"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded16.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User view the transaction timed out pop up",
  "keyword": "When "
});
formatter.match({
  "location": "GlobalPOC.user_should_be_able_to_view_reviewbag()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded17.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Application is timed out",
  "keyword": "Then "
});
formatter.match({
  "location": "GlobalPOC.user_should_be_not_able_to_view_transaction_timedout()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded18.png");
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "User should not be able to view Review My bag Page",
  "keyword": "And "
});
formatter.match({
  "location": "GlobalPOC.user_should_be_not_able_to_view_ReviewMybagPage()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded19.png");
formatter.afterstep({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});