package stepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.GlobeLogin;

public class GlobalPOC extends BaseClass {
//	private static final Logger logger = LogManager.getLogger(BaseClass.class);
	@Before
	public void setup() throws IOException {
		// Logger
		logger.info("One Globe"); // Added logger
		logger.trace("We've just greeted the user!");
        logger.debug("We've just greeted the user!");
        logger.info("We've just greeted the user!");
        logger.warn("We've just greeted the user!");
        logger.error("We've just greeted the user!");
        logger.fatal("We've just greeted the user!");
		//logger=Logger.getLogger("One Globe"); //Added logger
		//PropertyConfigurator.configure("Log4j.properties");// Added logger
	
		// Reading properties
		configProp = new Properties();
		FileInputStream configPropfile = new FileInputStream("config.properties");
		configProp.load(configPropfile);

		String br = configProp.getProperty("browser");

		if (br.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", configProp.getProperty("chromepath"));
			driver = new ChromeDriver();
		} else if (br.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", configProp.getProperty("firefoxpath"));
			driver = new FirefoxDriver();
		} else if (br.equals("ie")) {
			System.setProperty("webdriver.ie.driver", configProp.getProperty("iepath"));
			driver = new InternetExplorerDriver();
		}

		logger.info("******** Launching browser*********");
	}
	@AfterStep
	 public void tearDown(Scenario scenario) {
	if(scenario.isFailed()) {
	 final byte[] scnshot  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	 scenario.embed(scnshot, "image/png");
	  }else {
		  final byte[] scnshot  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		  scenario.embed(scnshot, "image/png");
	  }
	 }
	
	@After
	
	public void closeBrowser() {
		driver.quit();
	}
	
	@Given("User can be able to Launch Chrome browser")
	public void user_Launch_Chrome_browser() throws Exception {

		gp = new GlobeLogin(driver);
		
	}

	@When("User open URL {string}")
	public void user_opens_URL(String url) throws Exception {
		logger.info("******** Opening URL*********");
		driver.get(url);
		driver.manage().window().maximize();
		Thread.sleep(15000);
		Reporter.log(url);
	}

	@When("Page title should be {string}")
	public void page_Title_should_be(String title) throws Exception {

		if (!driver.getPageSource().contains("Discover more products in our Globe shop")) {
			driver.close();
			logger.info("******** Login Failed*********");
			Assert.assertTrue(false);
		} else {
			logger.info("******** Login Passed*********");
			Assert.assertTrue(driver.getTitle().contains(title));
			Thread.sleep(2000);

		}
		Thread.sleep(3000);

	}

	@Then("Click on BuyButton")
	public void click_on_Login() throws Exception {
		logger.info("******** started login*********");
		// driver.findElement(By.xpath(""))
		gp.navigateToXtreme_Home_Prepaid_WiFi();
		BaseClass.screenshot("BuyButtonPage");
		Thread.sleep(3000);
		Reporter.log(" Buy Button Page ");
	}

	@When("User should be able to check the buy now button")
	public void user_click_on_Log_out_link() throws Exception {
		logger.info("******** Buy Button should be displayed *********");
		if (!driver.getPageSource().contains("Globe at Home")) {
			driver.close();
			logger.info("******** Login Failed*********");
			Assert.assertTrue(false);
		} else {
			logger.info("******** Login Passed*********");
			Thread.sleep(2000);
			gp.buynowbtnisDisplayed();
			Thread.sleep(2000);
			BaseClass.screenshot("BuyButton Page Verification");
			Reporter.log("Buy Button should be displayed");
		}

	}

	@Then("User can view CheckOut Page")
	public void user_can_clickon_BuynowButton() throws Exception {
		gp.navigateTocheckOutpage();
		BaseClass.screenshot("Check out Page");
		Reporter.log("Check out Page should be displayed");
	}

	// Verify Checkout Details..........................................

	@Then("User can view CheckoutDetails {string}")
	public void user_can_view_Dashboad(String MobileNumber) throws Exception {
		gp.getcheckoutdetails(MobileNumber);
		BaseClass.screenshot("Check out Page Details Verification");
	}

	@When("User should be able to view Review My bag Page")
	public void verifyReviewPage() throws Exception {
		gp.verificationofreviewmybag();
		BaseClass.screenshot("Review Page Verification");
	}

	@Then("User should get Review My bag Page Text")
	public void user_should_found_Name_in_the_Search_table() throws Exception {
		gp.getTextforReviewpage();
		BaseClass.screenshot("Review My bag Page Text Verification");
	}

	@When("User view the transaction timed out pop up")
	public void user_should_be_able_to_view_reviewbag() throws Exception {
		Thread.sleep(10000);

		gp.verificationoftimedout();
		BaseClass.screenshot("popup");
		// throw new PendingException();
	}

	@Then("Application is timed out")
	public void user_should_be_not_able_to_view_transaction_timedout() throws Exception {
		gp.ClickontryAgainbutton();

		BaseClass.screenshot("Verification of transaction timed out");
	}

	@Then("User should not be able to view Review My bag Page")
	public void user_should_be_not_able_to_view_ReviewMybagPage() throws Exception {
		driver.navigate().refresh();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='btn btn-primary buynow-btn']")));
		System.out.println(element.getText());
		// Thread.sleep(15000);
		// gp.buynowbtnisDisplayed();
		BaseClass.screenshot("Verification of transaction timed out");
	}
}
