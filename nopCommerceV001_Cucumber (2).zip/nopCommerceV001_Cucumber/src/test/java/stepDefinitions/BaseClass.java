package stepDefinitions;

import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.util.Date;
import java.util.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;
import pageObjects.GlobeLogin;

public class BaseClass {

	public static WebDriver driver;
	public GlobeLogin gp;
	//public static Logger logger;
	public static Logger logger =LogManager.getLogger(BaseClass.class);;
	public Properties configProp;

	// Created for generating random string for Unique email
	public static String randomestring() {
		String generatedString1 = RandomStringUtils.randomAlphabetic(5);
		return (generatedString1);
	}
	public static byte[] getByteScreenshot() throws IOException 
	{
	    File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    byte[] fileContent = FileUtils.readFileToByteArray(src);
	    return fileContent;
	}
	
	public static void screenshot(String screenname) throws Exception {
		File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(file, new File(
				"C:\\Users\\LENOVO\\Downloads\\Selenium_Java full course\\Cucumber_BDD Framework\\Cucumber-Session7-Framework-part4\\nopCommerceV001_Cucumber\\test-output\\screenshots\\"
						+ screenname + ".png"));

	}

	public static String screenshot1(String screenName) throws IOException {

		TakesScreenshot screen = (TakesScreenshot) driver;
		File src = screen.getScreenshotAs(OutputType.FILE);

		String dest = "/BDD_Globe/test-output/screenshots" + screenName + randomestring() + ".png"; // set any path
																									// where you want to
																									// save screenshot

		File target = new File(dest);
		FileUtils.copyFile(src, target);

		return dest;
	}

	public static String getPopupMessage(final WebDriver driver) {
		String message = null;
		try {
			Alert alert = driver.switchTo().alert();
			message = alert.getText();
			alert.accept();
		} catch (Exception e) {
			message = null;
		}
		System.out.println("message" + message);
		return message;
	}

	public static void insertText(WebDriver driver, By locator, String value) {
		WebElement field = driver.findElement(locator);
		field.clear();
		field.sendKeys(value);
	}

	public static String tooltipText(WebDriver driver, By locator) {
		String tooltip = driver.findElement(locator).getAttribute("title");
		return tooltip;
	}

	public static void selectDropdown(WebDriver driver, By locator, String value) {
		new Select(driver.findElement(locator)).selectByVisibleText(value);
	}
}
