package pageObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.*;

public class GlobeLogin {
	public WebDriver ldriver;

	public GlobeLogin(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "(//*[text()='Buy'])[1]")
	@CacheLookup
	WebElement menu_Buy;

	@FindBy(xpath = "//*[contains(text(),'Xtreme Home Prepaid WiFi')]")
	@CacheLookup
	WebElement Xtreme_Home_Prepaid_WiFi;

	@FindBy(xpath = "//button[text()='Buy now']")
	@CacheLookup
	WebElement btnBuynow;
	
	@FindBy(xpath = "//*[contains(text(),'Globe At Home Prepaid WiFi')]")
	@CacheLookup
	WebElement getWifidetails;
	
	@FindBy(xpath = "//div[contains(@class,'ampount')]/span")
	@CacheLookup
	WebElement getfinaldetails;
	
	@FindBy(xpath = "//*[@placeholder='Mobile Number']")
	@CacheLookup
	WebElement txtMobileNumber;
	
	@FindBy(id = "gcashCheckout")
	@CacheLookup
	WebElement btncheckout;
	
	@FindBy(xpath = "(//button[@id='reviewMyBag'])[1]")
	@CacheLookup
	WebElement reviewmybag;
	
	@FindBy(xpath = "//*[contains(text(),'timed out!')]")
	@CacheLookup
	WebElement popuptransactiontimedout;
	
	@FindBy(xpath = "//*[contains(text(),'Try again')]")
	@CacheLookup
	WebElement btn_tryagain;
	
	@FindBy(xpath = "//*[@class='col-6 amount-1']/span")
	@CacheLookup
	WebElement txt_cashout;
	
	@FindBy(xpath = "//*[@class='col-6 free']/span")
	@CacheLookup
	WebElement txt_shipping;
	
	@FindBy(xpath = "//*[@class='plus-icon']")
	@CacheLookup
	WebElement btn_plus;
	
	@FindBy(xpath = "//*[@class='minus-icon']")
	@CacheLookup
	WebElement btn_minus;
	
	@FindBy(xpath = "//*[@class='description']")
	@CacheLookup
	WebElement txt_description;
	
	@FindBy(xpath = "//*[@class='promocode-content']/span")
	@CacheLookup
	WebElement txt_promo;
	
	
	public void navigateToXtreme_Home_Prepaid_WiFi() throws Exception {
		  menu_Buy.click();
		  Thread.sleep(2000);
			/*
			 * Actions action = new Actions(ldriver);
			 * action.moveToElement(menu_Buy).perform();
			 * action.moveToElement(Xtreme_Home_Prepaid_WiFi).perform();
			 * //action.moveToElement(Xtreme_Home_Prepaid_WiFi).click();
			 */		 
		  //Xtreme_Home_Prepaid_WiFi.click();
		 

	}
	public void buynowbtnisDisplayed() {
		Assert.assertEquals(true, btnBuynow.isDisplayed());
		
	}
	public void navigateTocheckOutpage() {
		btnBuynow.click();
		
	}
	
	public void getcheckoutdetails(String MobileNumber) throws Exception {
		Thread.sleep(4000);
		btn_plus.click();
		btn_plus.click();
		/*
		 * System.out.println("Get Wifi Details : "+getWifidetails.getText());
		 * System.out.println("Final Details:"+getfinaldetails.getText());
		 * System.out.println("Description :"+txt_description.getText());
		 * System.out.println("Cashout Details:"+txt_cashout.getText());
		 */
		Thread.sleep(4000);
		btn_minus.click();
		System.out.println("Get Wifi Details : "+getWifidetails.getText());
		System.out.println("Final Details:"+getfinaldetails.getText());
		System.out.println("Description :"+txt_description.getText());
		System.out.println("Cashout Details:"+txt_cashout.getText());
		txtMobileNumber.clear();
		txtMobileNumber.sendKeys(MobileNumber);
		
		System.out.println(txt_promo.getText());
		
		
		Thread.sleep(2000);
		
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("window.scrollBy(0,15000)");
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
		Thread.sleep(2000);
		btncheckout.click();
		Thread.sleep(10000);
		java.util.List<WebElement> otpNum = ldriver.findElements(By.xpath("//*[contains(@id,'otpInput_')]"));
		for(int i=1;i<=otpNum.size();i++) {
			
			ldriver.findElement(By.xpath("//*[contains(@id,'otpInput_"+i+"')]")).sendKeys("1");
		}
		
	}
	
	public void getTextforReviewpage() {
		System.out.println(getWifidetails.getText());
	}
	public void verificationofreviewmybag() {
		Assert.assertEquals(true, reviewmybag.isDisplayed());
	}
	public void verificationoftimedout() throws Exception {
		Thread.sleep(10000);
		WebDriverWait wait = new WebDriverWait(ldriver, 15);
		wait.until(ExpectedConditions.visibilityOf(popuptransactiontimedout));
		Assert.assertEquals(true, popuptransactiontimedout.isDisplayed());
	}
	public void ClickontryAgainbutton() {
		System.out.println(popuptransactiontimedout.getText());
		btn_tryagain.click();
		
	}
}
