package testRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions
		(
				/*
		features= {".//Features/Globe.feature"},
		glue="stepDefinitions",
		dryRun=false,
		monochrome=true,
		//plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
		//plugin = { "pretty", "html:test-output/html/" }
		
				plugin= {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","html:test-output/html/","json:test-output/json/Cucumber.json","junit:test-output/junitreports/Cucumber.xml"},,
				plugin = { "pretty", "html:test-output/html/","usage","json:test-output/Cucumber.json",
						"junit:test-output/Cucumber.xml"}*/
		
		//tags= {"@sanity"}

				features= {".//Features/"},
				glue="stepDefinitions",
				dryRun=false,
				monochrome=true,
				plugin= {"pretty","html:test-output/html/"},
				tags= {"@sanity,  @regression"}
				
				
				
				
				
				
		) 

public class TestRun {

 
}
